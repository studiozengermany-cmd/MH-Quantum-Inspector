/**
 * MH-Quantum Inspector — Content Script
 */
(function () {
  'use strict';

  const STATE = {
    active: false,
    hoveredEl: null,
    lastPayload: null,
    overlay: null,
    tooltip: null,
    contextMenu: null
  };

  let shadowRoot = null;

  function initShadowHost() {
    const host = document.createElement('div');
    host.id = 'mhq-shadow-host';
    host.style.cssText = 'position:fixed;top:0;left:0;width:0;height:0;overflow:visible;z-index:2147483647;pointer-events:none;';
    shadowRoot = host.attachShadow({ mode: 'open' });

    const style = document.createElement('style');
    style.textContent = `
      #mhq-overlay {
        position: fixed !important;
        pointer-events: none !important;
        z-index: 2147483647 !important;
        border: 2px solid #00f5ff !important;
        background: rgba(0, 245, 255, 0.08) !important;
        border-radius: 3px !important;
        display: none;
        box-shadow: 0 0 0 1px rgba(0,245,255,0.3), inset 0 0 20px rgba(0,245,255,0.05) !important;
        transition: all 0.08s ease !important;
      }
      #mhq-tooltip {
        position: fixed !important;
        z-index: 2147483647 !important;
        background: #0a0a0f !important;
        color: #00f5ff !important;
        font-family: 'JetBrains Mono', 'Fira Code', monospace !important;
        font-size: 11px !important;
        padding: 6px 10px !important;
        border-radius: 4px !important;
        border: 1px solid rgba(0,245,255,0.4) !important;
        pointer-events: none !important;
        display: none;
        white-space: nowrap !important;
        max-width: calc(100vw - 16px) !important;
        overflow: hidden !important;
        text-overflow: ellipsis !important;
        box-shadow: 0 4px 20px rgba(0,245,255,0.2) !important;
        backdrop-filter: blur(10px) !important;
      }
      #mhq-toast {
        position: fixed !important;
        bottom: 20px !important;
        right: 20px !important;
        z-index: 2147483647 !important;
        background: #0a0a0f !important;
        font-family: 'JetBrains Mono', monospace !important;
        font-size: 13px !important;
        font-weight: 600 !important;
        padding: 10px 16px !important;
        border-radius: 6px !important;
      }
      #mhq-context-menu {
        position: fixed !important;
        z-index: 2147483647 !important;
        width: 300px !important;
      }
      @keyframes mhq-slide-in {
        from { transform: translateY(10px); opacity: 0; }
        to { transform: translateY(0); opacity: 1; }
      }
    `;
    shadowRoot.appendChild(style);
    document.documentElement.appendChild(host);
  }

  function init() {
    initShadowHost();
    createOverlay();
    createTooltip();
    bindMessages();
  }

  function createOverlay() {
    STATE.overlay = document.createElement('div');
    STATE.overlay.id = 'mhq-overlay';
    shadowRoot.appendChild(STATE.overlay);
  }

  function createTooltip() {
    STATE.tooltip = document.createElement('div');
    STATE.tooltip.id = 'mhq-tooltip';
    shadowRoot.appendChild(STATE.tooltip);
  }

  function isOwnUI(el) {
    if (!el) return false;
    if (el.id === 'mhq-shadow-host') return true;
    const root = el.getRootNode?.();
    if (shadowRoot && root === shadowRoot) return true;
    if (root && root !== document && root.host?.id === 'mhq-shadow-host') return true;
    if (shadowRoot?.contains?.(el)) return true;
    return !!el.closest?.('#mhq-shadow-host, #mhq-overlay, #mhq-tooltip, #mhq-context-menu, #mhq-toast');
  }

  function isContextValid() {
    try {
      if (!chrome?.runtime?.id || typeof chrome.runtime.sendMessage !== 'function') {
        deactivate();
        return false;
      }
      return true;
    } catch (_) {
      deactivate();
      return false;
    }
  }

  function highlightElement(el) {
    if (!el || el === document.documentElement || el === document.body || isOwnUI(el)) return;
    const rect = el.getBoundingClientRect();

    Object.assign(STATE.overlay.style, {
      display: 'block',
      top: `${rect.top}px`,
      left: `${rect.left}px`,
      width: `${rect.width}px`,
      height: `${rect.height}px`
    });

    const selector = (window.MHDomCrawler?.getUniqueSelector?.(el))
      || (window.MHDomCrawler?.getSelector?.(el))
      || el.tagName?.toLowerCase?.()
      || 'unknown';
    const dims = `${Math.round(rect.width)}×${Math.round(rect.height)}`;
    STATE.tooltip.textContent = `${selector}  ${dims}px`;

    const ttTop = rect.top > 30 ? rect.top - 28 : rect.bottom + 4;
    STATE.tooltip.style.top = `${Math.max(8, ttTop)}px`;
    STATE.tooltip.style.left = `${Math.max(8, Math.min(rect.left, window.innerWidth - 20))}px`;
    STATE.tooltip.style.display = 'block';
  }

  function clearHighlight() {
    STATE.overlay.style.display = 'none';
    STATE.tooltip.style.display = 'none';
  }

  function activate() {
    if (STATE.active) return;
    STATE.active = true;
    document.addEventListener('mouseover', onMouseOver, true);
    document.addEventListener('mouseout', onMouseOut, true);
    document.addEventListener('click', onClick, true);
    document.addEventListener('keydown', onKeyDown, true);
    document.documentElement.style.cursor = 'crosshair';
    showToast('Inspector active — click any element', 'info');
  }

  function deactivate() {
    if (!STATE.active) return;
    STATE.active = false;
    document.removeEventListener('mouseover', onMouseOver, true);
    document.removeEventListener('mouseout', onMouseOut, true);
    document.removeEventListener('click', onClick, true);
    document.removeEventListener('keydown', onKeyDown, true);
    document.documentElement.style.cursor = '';
    clearHighlight();
    removeContextMenu();
  }

  function onMouseOver(e) {
    if (!isContextValid()) return;
    if (isOwnUI(e.target)) return;
    STATE.hoveredEl = e.target;
    highlightElement(e.target);
  }

  function onMouseOut() {
    clearHighlight();
  }

  function onClick(e) {
    if (!isContextValid()) return;
    if (isOwnUI(e.target)) return;
    e.preventDefault();
    e.stopPropagation();

    const el = e.target;
    if (!el || el === document.documentElement) return;

    const crawlData = window.MHDomCrawler.crawl(el);
    if (!crawlData) return;

    const payload = window.MHPayloadSchema.build(crawlData, '', 'debug');
    STATE.lastPayload = payload;

    chrome.runtime.sendMessage({
      type: 'STORE_PAYLOAD',
      payload: window.MHPayloadSchema.compact(payload)
    });

    showContextMenu(e.clientX, e.clientY, payload);
    clearHighlight();
  }

  function onKeyDown(e) {
    if (!isContextValid()) return;
    if (e.key === 'Escape') deactivate();
  }

  function showContextMenu(x, y, payload) {
    removeContextMenu();

    const menu = document.createElement('div');
    menu.id = 'mhq-context-menu';
    const el = payload.element.identity;
    const selector = el.selector;

    menu.innerHTML = `
      <div class="mhq-menu-header">
        <span class="mhq-menu-tag"></span>
        <span class="mhq-menu-sel"></span>
        <button class="mhq-menu-close" id="mhq-close" type="button" title="Close">✕</button>
      </div>
      <div class="mhq-menu-section">
        <div class="mhq-section-label">QUICK COPY</div>
        <button class="mhq-btn mhq-btn-primary" data-action="copy-prompt-debug" type="button">Copy Debug Prompt</button>
        <button class="mhq-btn" data-action="copy-prompt-css" type="button">Copy Fix CSS Prompt</button>
        <button class="mhq-btn" data-action="copy-prompt-a11y" type="button">Copy A11Y Audit Prompt</button>
        <button class="mhq-btn" data-action="copy-prompt-explain" type="button">Copy Explain Prompt</button>
      </div>
      <div class="mhq-menu-section">
        <div class="mhq-section-label">CUSTOM INTENT</div>
        <textarea class="mhq-intent-input" id="mhq-intent" placeholder="What do you want AI to do with this element?..." rows="3"></textarea>
        <button class="mhq-btn mhq-btn-accent" data-action="copy-custom" type="button">Copy Custom Prompt</button>
      </div>
      <div class="mhq-menu-section">
        <div class="mhq-section-label">RAW DATA</div>
        <button class="mhq-btn" data-action="copy-json" type="button">Copy JSON Payload</button>
        <button class="mhq-btn" data-action="copy-selector" type="button">Copy Selector</button>
      </div>
    `;

    menu.querySelector('.mhq-menu-tag').textContent = el.tag;
    menu.querySelector('.mhq-menu-sel').textContent = selector.slice(0, 35) + (selector.length > 35 ? '…' : '');

    const menuW = 300;
    const menuH = 400;
    const left = x + menuW > window.innerWidth ? Math.max(8, x - menuW) : x + 8;
    const top = y + menuH > window.innerHeight ? Math.max(8, y - menuH) : y + 8;
    Object.assign(menu.style, {
      position: 'fixed',
      zIndex: '2147483647',
      left: `${left}px`,
      top: `${top}px`,
      width: '300px'
    });

    shadowRoot.appendChild(menu);
    STATE.contextMenu = menu;

    menu.querySelector('#mhq-close').addEventListener('click', () => {
      removeContextMenu();
      deactivate();
    });

    menu.addEventListener('click', (e) => {
      e.stopPropagation();
      const btn = e.target.closest('[data-action]');
      if (!btn) return;
      const intent = menu.querySelector('#mhq-intent')?.value || '';
      handleMenuAction(btn.dataset.action, payload, intent);
    });

    setTimeout(() => document.addEventListener('click', onOutsideClick, { once: true, capture: true }), 100);
  }

  function onOutsideClick(e) {
    if (!STATE.contextMenu) return;
    const path = typeof e.composedPath === 'function' ? e.composedPath() : [e.target];
    const clickedInside = path.includes(STATE.contextMenu) || STATE.contextMenu.contains(path[0]);
    if (!clickedInside) removeContextMenu();
  }

  function removeContextMenu() {
    STATE.contextMenu?.remove();
    STATE.contextMenu = null;
  }

  function handleMenuAction(action, payload, intent) {
    const gen = window.MHPromptGenerator;
    const el = payload.element;
    const actions = {
      'copy-prompt-debug': () => copyText(gen.generate(el, intent, 'debug')),
      'copy-prompt-css': () => copyText(gen.generate(el, intent, 'fix_css')),
      'copy-prompt-a11y': () => copyText(gen.generate(el, intent, 'accessibility')),
      'copy-prompt-explain': () => copyText(gen.generate(el, intent, 'explain')),
      'copy-custom': () => copyText(gen.generate(el, intent, 'custom')),
      'copy-json': () => copyText(window.MHPayloadSchema.serialize(payload)),
      'copy-selector': () => copyText(el.identity.selector)
    };

    const handler = actions[action];
    if (!handler) return;
    Promise.resolve(handler()).then(() => {
      showToast('Copied to clipboard!', 'success');
      removeContextMenu();
      deactivate();
    });
  }

  async function copyText(text) {
    try {
      await navigator.clipboard.writeText(text);
    } catch (_) {
      const ta = document.createElement('textarea');
      ta.value = text;
      ta.style.position = 'fixed';
      ta.style.opacity = '0';
      document.body.appendChild(ta);
      ta.select();
      document.execCommand('copy');
      ta.remove();
    }
  }

  function showToast(message, type = 'info') {
    shadowRoot.getElementById('mhq-toast')?.remove();
    const toast = document.createElement('div');
    toast.id = 'mhq-toast';
    toast.textContent = message;
    const colors = { info: '#00f5ff', success: '#00ff88', error: '#ff4444', warning: '#ffaa00' };
    const color = colors[type] || colors.info;
    toast.style.cssText = [
      `color: ${color}`,
      `border: 1px solid ${color}`,
      `box-shadow: 0 4px 24px ${color}33`,
      'animation: mhq-slide-in 0.2s ease'
    ].join(';');
    shadowRoot.appendChild(toast);
    setTimeout(() => toast.remove(), 2500);
  }

  function bindMessages() {
    chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
      switch (msg.type) {
        case 'TOGGLE_INSPECTOR':
          STATE.active ? deactivate() : activate();
          sendResponse({ active: STATE.active });
          break;
        case 'ACTIVATE_INSPECTOR':
          activate();
          sendResponse({ ok: true });
          break;
        case 'DEACTIVATE_INSPECTOR':
          deactivate();
          sendResponse({ ok: true });
          break;
        case 'GET_STATUS':
          sendResponse({ active: STATE.active, hasPayload: !!STATE.lastPayload });
          break;
        case 'GET_LAST_PAYLOAD':
          sendResponse({ payload: STATE.lastPayload });
          break;
        case 'COPY_LAST_PROMPT':
          if (STATE.lastPayload) {
            const prompt = window.MHPromptGenerator.generate(STATE.lastPayload.element, '', msg.template || 'debug');
            copyText(prompt);
            showToast('Prompt copied!', 'success');
          }
          sendResponse({ ok: !!STATE.lastPayload });
          break;
        default:
          sendResponse({ ok: false, error: 'Unknown message type' });
      }
      return true;
    });
  }

  init();
})();
