/** MH-Quantum — Popup Controller (Light Mode multi-tab) */
let currentTab = null;
let inspectorActive = false;
let lastPayload = null;
let lastInspected = null;

async function init() {
  [currentTab] = await chrome.tabs.query({ active: true, currentWindow: true });
  await refreshStatus();
  await loadLastPayload();
  bindEvents();
  updatePromptPreview();
}

async function refreshStatus() {
  if (!currentTab?.id) return setStatus(false);
  try {
    const resp = await chrome.tabs.sendMessage(currentTab.id, { type: 'GET_STATUS' });
    setStatus(!!resp?.active);
  } catch (_) {
    setStatus(false);
  }
}

function setStatus(active) {
  inspectorActive = active;
  // If we had a global status indicator we'd update it here.
  // In the new UI, if no element is selected, we show empty state.
}

async function loadLastPayload() {
  const data = await chrome.storage.local.get(['lastPayload', 'lastInspected']);
  lastPayload = data.lastPayload || null;
  lastInspected = data.lastInspected || null;
  renderLastPayload();
}

function renderLastPayload() {
  const emptyState = document.getElementById('state-empty');
  const tabPanes = document.querySelectorAll('.tab-pane');
  const mainTabs = document.getElementById('main-tabs');
  
  if (!lastPayload?.element) {
    emptyState.style.display = 'flex';
    tabPanes.forEach(pane => pane.hidden = true);
    mainTabs.style.display = 'none';
    return;
  }

  emptyState.style.display = 'none';
  mainTabs.style.display = 'flex';
  
  // Make sure at least one tab is active
  if (!document.querySelector('.tab.active')) {
    document.querySelector('.tab').classList.add('active');
    document.getElementById('tab-selector').hidden = false;
  } else {
    const activeTab = document.querySelector('.tab.active').dataset.target;
    document.getElementById(activeTab).hidden = false;
  }

  const el = lastPayload.element;
  const geom = el.geometry || {};
  const stack = el.stacking || {};
  const styles = el.styles || {};

  // TAB 1: Selector & Info
  setText('val-selector', el.identity.selector);
  setText('val-tag', el.identity.tag);
  setText('val-id', el.identity.id ? `#${el.identity.id}` : '—');
  setText('val-classes', el.identity.classes.length ? el.identity.classes.join(' ') : '—');
  setText('val-text', el.text ? el.text.replace(/\s+/g, ' ').trim() : '—');

  // TAB 2: Layout
  setText('m-width', `${geom.width}px`);
  setText('m-height', `${geom.height}px`);
  setText('m-top', `${geom.y}px`);
  setText('m-left', `${geom.x}px`);
  setText('m-display', stack.display || 'block');
  setText('m-position', stack.position || 'static');
  setText('m-zindex', stack.zIndex || 'auto');

  // Box Model
  setText('bm-size', `${geom.width} × ${geom.height}`);
  const s = styles;
  setText('bm-mt', parseInt(s.marginTop)||0); setText('bm-mr', parseInt(s.marginRight)||0);
  setText('bm-mb', parseInt(s.marginBottom)||0); setText('bm-ml', parseInt(s.marginLeft)||0);
  
  setText('bm-bt', parseInt(s.borderTopWidth)||0); setText('bm-br', parseInt(s.borderRightWidth)||0);
  setText('bm-bb', parseInt(s.borderBottomWidth)||0); setText('bm-bl', parseInt(s.borderLeftWidth)||0);
  
  setText('bm-pt', parseInt(s.paddingTop)||0); setText('bm-pr', parseInt(s.paddingRight)||0);
  setText('bm-pb', parseInt(s.paddingBottom)||0); setText('bm-pl', parseInt(s.paddingLeft)||0);

  // TAB 3: Styles
  renderStylesList(styles);
  
  // TAB 4: AI Prompt
  updatePromptPreview();
}

function setText(id, text) {
  const el = document.getElementById(id);
  if (el) el.textContent = text;
}

function renderStylesList(styles) {
  const container = document.getElementById('styles-container');
  container.innerHTML = '';
  
  const importantProps = ['display', 'align-items', 'justify-content', 'gap', 'padding', 'margin', 'font-family', 'font-size', 'font-weight', 'line-height', 'border-radius', 'background-color', 'color', 'border', 'box-shadow', 'cursor'];
  
  importantProps.forEach(prop => {
    const key = prop.replace(/-([a-z])/g, g => g[1].toUpperCase());
    const val = styles[key];
    if (val && val !== 'none' && val !== 'auto' && val !== '0px') {
      const row = document.createElement('div');
      row.className = 'style-row';
      
      const propEl = document.createElement('div');
      propEl.className = 'style-prop';
      propEl.textContent = prop;
      row.appendChild(propEl);

      const valWrapper = document.createElement('div');
      valWrapper.className = 'style-val-wrapper';

      if (val.includes('rgb') || val.includes('#')) {
        const colorMatch = val.match(/(rgba?\(.*?\)|#[0-9a-fA-F]{3,8})/);
        if (colorMatch) {
          const colorBox = document.createElement('div');
          colorBox.className = 'style-color-box';
          colorBox.style.backgroundColor = colorMatch[0];
          valWrapper.appendChild(colorBox);
        }
      }
      
      const valEl = document.createElement('div');
      valEl.className = 'style-val';
      valEl.textContent = val;
      valWrapper.appendChild(valEl);
      
      row.appendChild(valWrapper);
      container.appendChild(row);
    }
  });
}

function updatePromptPreview() {
  if (!lastPayload?.element) return;
  const template = document.getElementById('prompt-template-select').value;
  let text = 'N/A';
  if (window.MHPromptGenerator) {
    text = window.MHPromptGenerator.generate(lastPayload.element, lastPayload.intent || '', template);
  } else {
    // Fallback if script missing
    text = `## Element Summary\nSelector: ${lastPayload.element.identity.selector}\n\nObjective: ${template}`;
  }
  document.getElementById('prompt-preview-text').textContent = text;
}

function bindEvents() {
  // Tab Switching
  document.querySelectorAll('.tab').forEach(tab => {
    tab.addEventListener('click', (e) => {
      document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
      document.querySelectorAll('.tab-pane').forEach(p => p.hidden = true);
      
      e.target.classList.add('active');
      const targetId = e.target.dataset.target;
      document.getElementById(targetId).hidden = false;
    });
  });

  // Start Inspecting
  document.getElementById('btn-activate-inspector')?.addEventListener('click', async () => {
    if (!currentTab?.id) return;
    try {
      await chrome.tabs.sendMessage(currentTab.id, { type: 'TOGGLE_INSPECTOR' });
      window.close();
    } catch (_) {
      showToast('⚠️ Cannot inspect this page', 'error');
    }
  });

  // Prompt Template Change
  document.getElementById('prompt-template-select').addEventListener('change', updatePromptPreview);

  // Copy Buttons
  document.querySelectorAll('[data-copy]').forEach(btn => {
    btn.addEventListener('click', async (e) => {
      const targetId = btn.dataset.copy;
      const text = document.getElementById(targetId).textContent;
      await navigator.clipboard.writeText(text);
      showToast('Copied to clipboard', 'success');
    });
  });

  document.getElementById('btn-copy-markdown').addEventListener('click', async () => {
    const text = document.getElementById('prompt-preview-text').textContent;
    await navigator.clipboard.writeText(text);
    showToast('Markdown copied to clipboard', 'success');
  });

  document.getElementById('btn-copy-prompt').addEventListener('click', async () => {
    const text = document.getElementById('prompt-preview-text').textContent;
    await navigator.clipboard.writeText(text);
    showToast('Prompt copied to clipboard', 'success');
  });

  // Header Actions
  document.getElementById('btn-pin')?.addEventListener('click', async () => {
    const url = chrome.runtime.getURL('popup/popup.html');
    await chrome.windows.create({
      url: url,
      type: 'popup',
      width: 340,
      height: 600
    });
    window.close();
  });

  document.getElementById('btn-close').addEventListener('click', () => window.close());
}

function showToast(message, type = 'info') {
  const toast = document.getElementById('toast');
  toast.textContent = message;
  toast.hidden = false;
  
  if (type === 'error') {
    toast.style.background = '#EF4444'; // Red
    toast.style.color = '#FFFFFF';
  } else if (type === 'success') {
    toast.style.background = '#10B981'; // Green (Test Xanh)
    toast.style.color = '#FFFFFF';
  } else {
    toast.style.background = '#0F1115'; // Charcoal default
    toast.style.color = '#FFFFFF';
  }
  
  clearTimeout(showToast._timer);
  showToast._timer = setTimeout(() => { toast.hidden = true; }, 5000);
}

document.addEventListener('DOMContentLoaded', init);
